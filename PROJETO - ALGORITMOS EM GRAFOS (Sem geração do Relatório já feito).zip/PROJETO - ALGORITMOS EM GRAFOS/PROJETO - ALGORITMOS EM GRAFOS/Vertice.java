import java.util.Objects;

/*
A classe vértice traz a representação de um nó (que seria um ponto no labirinto) no grafo
que modela o labirinto. Essa classe é fundamental para definir as posições onde o detento
e o minotauro podem estar. Ela é importante porque define a identidade única do grafo e as
regras de comparação para os elementos do mapa, garantindo que os algoritmos de busca funcionam 
corretamnete. 
-> Atributos: id (int): Um identificador numérioc único para o vértice 
              nome (String): o nome de exebição do vértice, formatado como "V" + id
-> Métodos: Vertice(int id): Método construtor que inicializa o id e define o nome */

public class Vertice {
    private int id;
    private String nome;

    public Vertice(int id) {
        this.id = id;
        this.nome = "V" + id;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Vertice vertice = (Vertice) o;
        return id == vertice.id && Objects.equals(nome, vertice.nome);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nome);
    }

    @Override
    public String toString() {
        return nome;
    }
}
