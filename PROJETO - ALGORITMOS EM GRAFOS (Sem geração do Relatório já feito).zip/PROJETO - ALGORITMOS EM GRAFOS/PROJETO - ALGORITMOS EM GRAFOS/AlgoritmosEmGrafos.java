import java.util.*;

public class AlgoritmosEmGrafos {
    // Dijkstra para calcular distâncias mínimas
        public static Map<Vertice, Integer> dijkstra(Labirinto labirinto, Vertice origem) {
            Map<Vertice, Integer> distancias = new HashMap<>();
            PriorityQueue<VerticeDistancia> fila = new PriorityQueue<>();

            for (Vertice v : labirinto.getVertices()) {
                distancias.put(v, Integer.MAX_VALUE);
            }
            distancias.put(origem, 0);
            fila.add(new VerticeDistancia(origem, 0));

            while (!fila.isEmpty()) {
                VerticeDistancia atual = fila.poll();
                Vertice verticeAtual = atual.vertice;

                for (Aresta aresta : labirinto.getArestasAdjacentes(verticeAtual)) {
                    Vertice vizinho = aresta.getDestino();
                    int novaDistancia = distancias.get(verticeAtual) + aresta.getCustoAresta();

                    if (novaDistancia < distancias.get(vizinho)) {
                        distancias.put(vizinho, novaDistancia);
                        fila.add(new VerticeDistancia(vizinho, novaDistancia));
                    }
                }
            }

            return distancias;
        }

        // BFS para encontrar caminho mínimo (sem pesos)
        public static List<Vertice> bfsCaminhoMinimo(Labirinto labirinto, Vertice origem, Vertice destino) {
            Map<Vertice, Vertice> predecessores = new HashMap<>();
            Queue<Vertice> fila = new LinkedList<>();
            Set<Vertice> visitados = new HashSet<>();

            fila.add(origem);
            visitados.add(origem);
            predecessores.put(origem, null);

            while (!fila.isEmpty()) {
                Vertice atual = fila.poll();

                if (atual.equals(destino)) break;

                for (Aresta aresta : labirinto.getArestasAdjacentes(atual)) {
                    Vertice vizinho = aresta.getDestino();
                    if (!visitados.contains(vizinho)) {
                        visitados.add(vizinho);
                        predecessores.put(vizinho, atual);
                        fila.add(vizinho);
                    }
                }
            }

            // Reconstruir caminho
            return reconstruirCaminho(predecessores, destino);
        }

        // Dijkstra para encontrar caminho mínimo (com pesos)
        public static List<Vertice> dijkstraCaminhoMinimo(Labirinto labirinto, Vertice origem, Vertice destino) {
            Map<Vertice, Integer> distancias = new HashMap<>();
            Map<Vertice, Vertice> predecessores = new HashMap<>();
            PriorityQueue<VerticeDistancia> fila = new PriorityQueue<>();

            for (Vertice v : labirinto.getVertices()) {
                distancias.put(v, Integer.MAX_VALUE);
                predecessores.put(v, null);
            }
            distancias.put(origem, 0);
            fila.add(new VerticeDistancia(origem, 0));

            while (!fila.isEmpty()) {
                VerticeDistancia atual = fila.poll();
                Vertice verticeAtual = atual.vertice;

                if (verticeAtual.equals(destino)) break;

                for (Aresta aresta : labirinto.getArestasAdjacentes(verticeAtual)) {
                    Vertice vizinho = aresta.getDestino();
                    int novaDistancia = distancias.get(verticeAtual) + aresta.getCustoAresta();

                    if (novaDistancia < distancias.get(vizinho)) {
                        distancias.put(vizinho, novaDistancia);
                        predecessores.put(vizinho, verticeAtual);
                        fila.add(new VerticeDistancia(vizinho, novaDistancia));
                    }
                }
            }

            return reconstruirCaminho(predecessores, destino);
        }

        private static List<Vertice> reconstruirCaminho(Map<Vertice, Vertice> predecessores, Vertice destino) {
            List<Vertice> caminho = new ArrayList<>();
            Vertice atual = destino;

            while (atual != null) {
                caminho.add(0, atual);
                atual = predecessores.get(atual);
            }

            return caminho.size() > 1 ? caminho : new ArrayList<>();
        }

        // Classe auxiliar para PriorityQueue
        private static class VerticeDistancia implements Comparable<VerticeDistancia> {
            Vertice vertice;
            int distancia;

            VerticeDistancia(Vertice vertice, int distancia) {
                this.vertice = vertice;
                this.distancia = distancia;
            }

            @Override
            public int compareTo(VerticeDistancia other) {
                return Integer.compare(this.distancia, other.distancia);
            }
        }
}

