import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 * Classe principal que simula o Labirinto de Creta
 * Implementa todas as especificações do projeto de Algoritmos em Grafos
 * 
 * @author Equipe do Projeto
 * @version 1.0
 * @date 2025
 */
public class Main {
    private Labirinto labirinto;
    private Detento detento;
    private Minotauro minotauro;
    private int tempoMaximo;
    private boolean deteccaoOcorrida;
    private int momentoDeteccao;
    private boolean encontroOcorreu;
    private int momentoEncontro;
    private int passosSimulacao;

    // Constantes para configuração
    private static final double CHANCE_VITORIA_DETENTO = 0.01;
    private static final int VELOCIDADE_PERSECUCAO = 2;

    /**
     * Método principal - ponto de entrada da aplicação
     */
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Uso: java Main <arquivo_labirinto>");
            System.out.println("Exemplo: java Main labirinto.txt");
            return;
        }

        Main simulacao = new Main();
        simulacao.executarSimulacao(args[0]);
    }

    /**
     * Executa a simulação completa do labirinto
     */
    public void executarSimulacao(String arquivoEntrada) {
        System.out.println("=== INICIANDO SIMULAÇÃO DO LABIRINTO DE CRETA ===");
        
        // Fase 1: Leitura e validação do arquivo de entrada
        if (!lerEValidarArquivoEntrada(arquivoEntrada)) {
            System.out.println(" Erro na leitura ou validação do arquivo de entrada.");
            return;
        }

        // Fase 2: Execução da simulação passo a passo
        executarSimulacaoPassoAPasso();

        // Fase 3: Geração do relatório detalhado
        gerarRelatorioCompleto();
        
        // Fase 4: Análise de eficiência
        analisarEficiencia();
    }

    /**
     * Lê e valida o arquivo de entrada conforme especificação
     */
    private boolean lerEValidarArquivoEntrada(String arquivoEntrada) {
        try (BufferedReader br = new BufferedReader(new FileReader(arquivoEntrada))) {
            // Ler número de vértices e arestas
            int n = Integer.parseInt(br.readLine().trim());
            int m = Integer.parseInt(br.readLine().trim());

            // Validar parâmetros básicos
            if (n <= 0 || m < 0) {
                System.out.println("Erro: Número de vértices ou arestas inválido.");
                return false;
            }

            // Inicializar labirinto
            labirinto = new Labirinto();

            // Criar vértices com IDs sequenciais
            for (int i = 0; i < n; i++) {
                labirinto.adicionarVertice(new Vertice(i));
            }

            // Ler e validar arestas
            for (int i = 0; i < m; i++) {
                String[] linha = br.readLine().trim().split("\\s+");
                if (linha.length != 3) {
                    System.out.println("Erro: Formato de aresta inválido na linha " + (i + 3));
                    return false;
                }

                int u = Integer.parseInt(linha[0]);
                int v = Integer.parseInt(linha[1]);
                int peso = Integer.parseInt(linha[2]);

                // Validar vértices e peso
                if (u < 0 || u >= n || v < 0 || v >= n) {
                    System.out.println("Erro: Vértice inválido na aresta " + i);
                    return false;
                }
                if (peso <= 0) {
                    System.out.println("Erro: Peso da aresta deve ser positivo");
                    return false;
                }

                Vertice verticeU = encontrarVerticePorId(u);
                Vertice verticeV = encontrarVerticePorId(v);
                
                labirinto.adicionarAresta(new Aresta(verticeU, verticeV, peso));
            }

            // Ler configurações restantes com validação
            int entradaId = Integer.parseInt(br.readLine().trim());
            int saidaId = Integer.parseInt(br.readLine().trim());
            int minotauroId = Integer.parseInt(br.readLine().trim());
            int alcance = Integer.parseInt(br.readLine().trim());
            tempoMaximo = Integer.parseInt(br.readLine().trim());

            // Validar configurações
            if (entradaId == saidaId) {
                System.out.println("Erro: Entrada e saída devem ser diferentes");
                return false;
            }
            if (entradaId == minotauroId || saidaId == minotauroId) {
                System.out.println("Erro: Minotauro não pode estar na entrada ou saída");
                return false;
            }
            if (alcance <= 0 || tempoMaximo <= 0) {
                System.out.println("Erro: Alcance e tempo máximo devem ser positivos");
                return false;
            }

            // Configurar labirinto
            Vertice entrada = encontrarVerticePorId(entradaId);
            Vertice saida = encontrarVerticePorId(saidaId);
            Vertice posMinotauro = encontrarVerticePorId(minotauroId);

            if (entrada == null || saida == null || posMinotauro == null) {
                System.out.println("Erro: Vértices de configuração não encontrados");
                return false;
            }

            labirinto.setEntrada(entrada);
            labirinto.setSaida(saida);
            labirinto.setPosicaoMinotauro(posMinotauro);
            labirinto.setAlcance(alcance);
            labirinto.setTempoMaximo(tempoMaximo);

            // Verificar conectividade do grafo
            if (!verificarConectividade(entrada, saida)) {
                System.out.println("Aviso: Labirinto pode não ser totalmente conexo");
            }

            // Inicializar personagens
            detento = new Detento(labirinto, entrada);
            minotauro = new Minotauro(labirinto, detento);

            System.out.println(" Arquivo de entrada carregado com sucesso!");
            System.out.println("   Vértices: " + n + ", Arestas: " + m);
            System.out.println("   Entrada: " + entrada + ", Saída: " + saida);
            System.out.println("   Minotauro: " + posMinotauro + ", Alcance: " + alcance);
            System.out.println("   Tempo máximo: " + tempoMaximo);

            return true;

        } catch (IOException e) {
            System.out.println("Erro de E/S ao ler arquivo: " + e.getMessage());
            return false;
        } catch (NumberFormatException e) {
            System.out.println("Erro de formato numérico no arquivo: " + e.getMessage());
            return false;
        } catch (Exception e) {
            System.out.println("Erro inesperado: " + e.getMessage());
            return false;
        }
    }

    /**
     * Verifica conectividade básica entre entrada e saída usando BFS
     */
    private boolean verificarConectividade(Vertice entrada, Vertice saida) {
        Set<Vertice> visitados = new HashSet<>();
        Queue<Vertice> fila = new LinkedList<>();
        
        fila.add(entrada);
        visitados.add(entrada);
        
        while (!fila.isEmpty()) {
            Vertice atual = fila.poll();
            
            if (atual.equals(saida)) {
                return true;
            }
            
            for (Aresta aresta : labirinto.getArestasAdjacentes(atual)) {
                Vertice vizinho = aresta.getDestino();
                if (!visitados.contains(vizinho)) {
                    visitados.add(vizinho);
                    fila.add(vizinho);
                }
            }
        }
        
        return false;
    }

    /**
     * Executa a simulação passo a passo conforme especificação
     */
    private void executarSimulacaoPassoAPasso() {
        deteccaoOcorrida = false;
        encontroOcorreu = false;
        momentoDeteccao = -1;
        momentoEncontro = -1;
        passosSimulacao = 0;

        System.out.println("\n=== EXECUTANDO SIMULAÇÃO ===");

        while (passosSimulacao < tempoMaximo && 
               detento.estaVivo() && 
               !detento.encontrouSaida() && 
               !encontroOcorreu) {
            
            passosSimulacao++;
            
            System.out.println("\n--- Passo " + passosSimulacao + " ---");

            // 1. Verificar detecção do minotauro
            if (!deteccaoOcorrida && minotauro.devePerseguir()) {
                deteccaoOcorrida = true;
                momentoDeteccao = passosSimulacao;
                System.out.println(" Minotauro detectou o prisioneiro!");
            }

            // 2. Movimentar detento (1 vértice por passo)
            System.out.println("Prisioneiro move de: " + detento.getAtualPosicao());
            detento.mover();
            System.out.println("Prisioneiro move para: " + detento.getAtualPosicao());

            // 3. Verificar se detento encontrou saída
            if (detento.encontrouSaida()) {
                System.out.println(" Prisioneiro encontrou a saída!");
                break;
            }

            // 4. Movimentar minotauro
            if (deteccaoOcorrida) {
                System.out.println("Minotauro em perseguição move de: " + minotauro.getAtualPosicao());
                minotauro.mover();
                System.out.println("Minotauro em perseguição move para: " + minotauro.getAtualPosicao());
            } else {
                System.out.println("Minotauro em patrulha move de: " + minotauro.getAtualPosicao());
                minotauro.mover();
                System.out.println("Minotauro em patrulha move para: " + minotauro.getAtualPosicao());
            }

            // 5. Verificar encontro
            if (minotauro.encontrouPrisioneiro()) {
                encontroOcorreu = true;
                momentoEncontro = passosSimulacao;
                System.out.println(" ENCONTRO: Minotauro alcançou o prisioneiro!");
                
                // Realizar batalha conforme especificação (1% de chance)
                if (detento.batalharComMinotauro()) {
                    System.out.println(" PRISIONEIRO VENCEU A BATALHA! (1% de chance)");
                } else {
                    System.out.println(" Prisioneiro foi derrotado pelo Minotauro");
                }
            }

            // 6. Verificar tempo
            if (detento.getTempoRestante() <= 0) {
                System.out.println(" Tempo da comida esgotou!");
            }
        }
    }

    /**
     * Gera relatório completo conforme especificação
     */
    private void gerarRelatorioCompleto() {
        System.out.println("\n" + "=".repeat(50));
        System.out.println("         RELATÓRIO FINAL DA SIMULAÇÃO");
        System.out.println("=".repeat(50));

        // 1. Resultado final
        System.out.println("\n RESULTADO FINAL:");
        if (detento.encontrouSaida()) {
            System.out.println("    O PRISIONEIRO ESCAPOU DO LABIRINTO!");
        } else if (encontroOcorreu && !detento.batalharComMinotauro()) {
            System.out.println("    O PRISIONEIRO FOI CAPTURADO E MORREU PELO MINOTAURO!");
        } else if (detento.getTempoRestante() <= 0) {
            System.out.println("    O PRISIONEIRO MORREU DE FOME!");
        } else {
            System.out.println("    O PRISIONEIRO NÃO CONSEGUIU ESCAPAR!");
        }

        // 2. Tempo restante
        System.out.println("\n  INFORMAÇÕES DE TEMPO:");
        System.out.println("   Tempo máximo disponível: " + tempoMaximo);
        System.out.println("   Tempo restante de comida: " + detento.getTempoRestante());
        System.out.println("   Passos executados: " + passosSimulacao);

        // 3. Sequência de vértices visitados pelo prisioneiro
        System.out.println("\n CAMINHO PERCORRIDO PELO PRISIONEIRO:");
        List<Vertice> caminhoDetento = detento.getCaminhoPercorrido();
        if (caminhoDetento.isEmpty()) {
            System.out.println("   Nenhum movimento registrado.");
        } else {
            for (int i = 0; i < caminhoDetento.size(); i++) {
                System.out.print("   " + caminhoDetento.get(i).getNome());
                if (i < caminhoDetento.size() - 1) {
                    System.out.print(" → ");
                }
                if ((i + 1) % 8 == 0) {
                    System.out.println();
                }
            }
            System.out.println("\n   Total de vértices visitados: " + caminhoDetento.size());
            
            // Eficiência do caminho
            double eficiencia = (double) caminhoDetento.size() / labirinto.getVertices().size();
            System.out.printf("   Eficiência de exploração: %.2f%%\n", (1 - eficiencia) * 100);
        }

        // 4. Informações sobre perseguição
        System.out.println("\n INFORMAÇÕES SOBRE A PERSEGUIÇÃO:");
        if (deteccaoOcorrida) {
            System.out.println("    Detecção ocorreu no passo: " + momentoDeteccao);
            
            if (encontroOcorreu) {
                System.out.println("    Encontro ocorreu no passo: " + momentoEncontro);
                System.out.println("    Passos entre detecção e encontro: " + (momentoEncontro - momentoDeteccao));
            } else {
                System.out.println("    Prisioneiro evitou o encontro após detecção");
            }

            // Caminho de perseguição do minotauro
            List<Vertice> trilhaPerseguicao = minotauro.getTrilhaDaPerseguicao();
            System.out.println("\n    CAMINHO DO MINOTAURO NA PERSEGUIÇÃO:");
            if (trilhaPerseguicao.isEmpty()) {
                System.out.println("   Nenhum movimento de perseguição registrado.");
            } else {
                for (int i = 0; i < trilhaPerseguicao.size(); i++) {
                    System.out.print("   " + trilhaPerseguicao.get(i).getNome());
                    if (i < trilhaPerseguicao.size() - 1) {
                        System.out.print(" → ");
                    }
                    if ((i + 1) % 8 == 0) {
                        System.out.println();
                    }
                }
                System.out.println("\n   Total de vértices na perseguição: " + trilhaPerseguicao.size());
            }
        } else {
            System.out.println("    Minotauro não detectou o prisioneiro");
        }

        // 5. Estatísticas da simulação
        System.out.println("\n ESTATÍSTICAS DA SIMULAÇÃO:");
        System.out.println("   Taxa de sucesso do prisioneiro: " + 
            (detento.encontrouSaida() ? "100%" : "0%"));
        System.out.println("   Eficácia da perseguição: " + 
            (encontroOcorreu ? "100%" : "0%"));
    }

    /**
     * Analisa a eficiência dos algoritmos utilizados
     */
    private void analisarEficiencia() {
        System.out.println("\n" + "=".repeat(50));
        System.out.println("         ANÁLISE DE EFICIÊNCIA");
        System.out.println("=".repeat(50));

        System.out.println("\n ANÁLISE DOS ALGORITMOS IMPLEMENTADOS:");

        // Complexidade dos algoritmos
        System.out.println("   1. DIJKSTRA:");
        System.out.println("      - Complexidade: O((V + E) log V) com PriorityQueue");
        System.out.println("      - Uso: Cálculo de distâncias mínimas e caminhos ótimos");
        System.out.println("      - Aplicação: Perseguição inteligente do Minotauro");

        System.out.println("   2. BFS (Busca em Largura):");
        System.out.println("      - Complexidade: O(V + E)");
        System.out.println("      - Uso: Verificação de conectividade e caminhos sem pesos");
        System.out.println("      - Aplicação: Validação de labirinto conexo");

        System.out.println("   3. DFS (Busca em Profundidade):");
        System.out.println("      - Complexidade: O(V + E)");
        System.out.println("      - Uso: Exploração do labirinto pelo prisioneiro");
        System.out.println("      - Aplicação: Estratégia com backtracking (novelo de lã)");

        // Estruturas de dados utilizadas
        System.out.println("\n  ESTRUTURAS DE DADOS UTILIZADAS:");
        System.out.println("   - PriorityQueue: Para Dijkstra (ordenação eficiente)");
        System.out.println("   - HashMap: Para armazenamento eficiente de distâncias e predecessores");
        System.out.println("   - HashSet: Para controle de vértices visitados (O(1) para consultas)");
        System.out.println("   - Stack: Para implementação do backtracking (novelo de lã)");

        // Calibragem de parâmetros
        System.out.println("\n  CALIBRAGEM DE PARÂMETROS:");
        System.out.println("   - Alcance do Minotauro: " + labirinto.getAlcance());
        System.out.println("   - Tempo máximo: " + tempoMaximo);
        System.out.println("   - Chance de vitória: " + (CHANCE_VITORIA_DETENTO * 100) + "%");
        System.out.println("   - Velocidade de perseguição: " + VELOCIDADE_PERSECUCAO + " vértices/passo");

        System.out.println("\n RECOMENDAÇÕES PARA CALIBRAGEM:");
        System.out.println("   - Alcance muito alto: Minotauro muito eficiente");
        System.out.println("   - Alcance muito baixo: Perseguição raramente inicia");
        System.out.println("   - Tempo máximo: Balancear entre desafio e possibilidade");
    }

    /**
     * Encontra vértice por ID (O(n) - aceitável para labirintos de tamanho razoável)
     */
    private Vertice encontrarVerticePorId(int id) {
        for (Vertice v : labirinto.getVertices()) {
            if (v.getId() == id) {
                return v;
            }
        }
        return null;
    }
}