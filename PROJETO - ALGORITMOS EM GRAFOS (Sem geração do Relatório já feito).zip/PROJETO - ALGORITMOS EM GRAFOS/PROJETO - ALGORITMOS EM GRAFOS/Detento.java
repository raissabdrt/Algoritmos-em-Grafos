import java.util.List;
import java.util.Random;
import java.util.Stack;

class Detento extends Explorador {
    private Random dadosAleatorios;
    private int tempoRestante;
    private Stack<Vertice> pilha;
    private boolean saidaEncontrada;
    // Remover este construtor duplicado ou ajustá-lo
    public Detento(Labirinto labirinto, Vertice posicaoInicial) {
        super(labirinto, posicaoInicial);
        // Inicializar outras variáveis necessárias
        this.dadosAleatorios = new Random();
        this.tempoRestante = labirinto.getTempoMaximo(); // ou outro valor
        this.pilha = new Stack<>();
        this.pilha.push(posicaoInicial);
        this.saidaEncontrada = false;
    }

    @Override
    public void mover() {
        if (tempoRestante <= 0 || saidaEncontrada) return;

// Verificar se chegou na saída
        if (atualPosicao.equals(labirinto.getSaida())) {
            saidaEncontrada = true;
            return;
        }
        List<Vertice> vizinhosNaoVisitados = getVizinhosNaoVisitados();
        Vertice proximoVertice;
        if (!vizinhosNaoVisitados.isEmpty()) {
// Estratégia: escolher aleatoriamente entre vizinhos não visitados
            proximoVertice =
                    vizinhosNaoVisitados.get(dadosAleatorios.nextInt(vizinhosNaoVisitados.size()));
            pilha.push(atualPosicao);
        } else if (!pilha.isEmpty()) {
// Backtracking usando o "novelo de lã"
            proximoVertice = pilha.pop();
        } else {
            return; // Não há para onde mover
        }
        atualPosicao = proximoVertice;
        caminhoPercorrido.add(proximoVertice);
        tempoRestante--;
// Verificar se chegou na saída após movimento
        if (atualPosicao.equals(labirinto.getSaida())) {
            saidaEncontrada = true;
        }
    }
    public boolean encontrouSaida() { return saidaEncontrada; }
    public boolean estaVivo() { return tempoRestante > 0 && !saidaEncontrada; }
    public int getTempoRestante() { return tempoRestante; }
    public boolean batalharComMinotauro() {
        return dadosAleatorios.nextDouble() < 0.01; // 1% de chance de vitória
    }
}