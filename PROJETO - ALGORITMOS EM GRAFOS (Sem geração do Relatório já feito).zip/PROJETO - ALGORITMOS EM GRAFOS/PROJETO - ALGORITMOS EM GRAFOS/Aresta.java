public class Aresta {
    private  Vertice fonte;
    private Vertice destino;
    private int custoAresta;

    public Aresta(Vertice origem, Vertice destino, int peso) {
        this.fonte = origem;
        this.destino = destino;
        this.custoAresta = peso;
    }

    public Vertice getFonte() {
        return fonte;
    }

    public Vertice getDestino() {
        return destino;
    }

    public int getCustoAresta() {
        return custoAresta;
    }

    @Override
    public String toString() {
        return fonte.getNome() + " - " + destino.getNome() + " ("
                + custoAresta + ")";
    }
}
