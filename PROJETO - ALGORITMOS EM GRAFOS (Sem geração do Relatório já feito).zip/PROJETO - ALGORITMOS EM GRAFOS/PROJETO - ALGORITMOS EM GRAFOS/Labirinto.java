import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class Labirinto {
    private List<Vertice> vertices;
    private List<Aresta> arestas;
    private Map<Vertice,List<Aresta>> listaDeAdjacencias;
    private Vertice entrada;
    private Vertice saida;
    private Vertice posicaoDoMinotauro;
    private int alcance;
    private int tempoMaximo;

    public Labirinto() {
        vertices = new ArrayList<>();
        arestas = new ArrayList<>();
        listaDeAdjacencias = new HashMap<>();
    }

    public void adicionarVertice(Vertice V) {
        vertices.add(V);
        listaDeAdjacencias.put(V, new ArrayList<>());
    }
    public void adicionarAresta(Aresta A) {
        arestas.add(A);
        listaDeAdjacencias.get(A.getFonte()).add(A);
        listaDeAdjacencias.get(A.getDestino()).add(new Aresta(A.getDestino(), A.getFonte(), A.getCustoAresta()));
    }

    public List<Aresta> getArestasAdjacentes(Vertice V) {
        return listaDeAdjacencias.getOrDefault(V, new ArrayList<>());
    }


    public List<Vertice> getVertices() {
        return vertices;
    }

    public Vertice getEntrada() {
        return entrada;
    }

    public Vertice getSaida() {
        return saida;
    }

    public Vertice getPosicaoMinotauro() {
        return posicaoDoMinotauro;
    }

    public int getAlcance() {
        return alcance;
    }

    public int getTempoMaximo() {
        return tempoMaximo;
    }

    public void setEntrada(Vertice entrada) {
        this.entrada = entrada;
    }

    public void setSaida(Vertice saida) {
        this.saida = saida;
    }

    public void setPosicaoMinotauro(Vertice posicaoMinotauro) {
        this.posicaoDoMinotauro = posicaoMinotauro;
    }

    public void setAlcance(int alcance) {
        this.alcance = alcance;
    }

    public void setTempoMaximo(int tempoMaximo) {
        this.tempoMaximo = tempoMaximo;
    }

}

