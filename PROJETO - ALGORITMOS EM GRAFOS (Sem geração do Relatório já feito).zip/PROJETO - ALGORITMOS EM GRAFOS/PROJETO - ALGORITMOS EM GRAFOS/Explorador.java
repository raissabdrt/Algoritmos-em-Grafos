import java.util.ArrayList;
import java.util.List;

abstract class Explorador {
    protected Vertice atualPosicao;
    protected Labirinto labirinto;
    protected List<Vertice> caminhoPercorrido;

    public Explorador(Labirinto labirinto, Vertice posicaoInicio) {
        this.labirinto = labirinto;
        this.atualPosicao = posicaoInicio;
        this.caminhoPercorrido = new ArrayList<>();
        caminhoPercorrido.add(posicaoInicio);
    }
    public abstract void mover();
    public Vertice getAtualPosicao() { return atualPosicao; }
    public List<Vertice> getCaminhoPercorrido() { return caminhoPercorrido; }
    protected List<Vertice> getVizinhosNaoVisitados() {
        List<Vertice> vizinhos = new ArrayList<>();
        for (Aresta aresta : labirinto.getArestasAdjacentes(atualPosicao)) {
            Vertice vizinho = aresta.getDestino();
            if (!caminhoPercorrido.contains(vizinho)) {
                vizinhos.add(vizinho);
            }
        }
        return vizinhos;
    }
}
