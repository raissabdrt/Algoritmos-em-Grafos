import java.util.*;

public class Minotauro extends Explorador {
    private int alcance;
    private boolean emPerseguicao;
    private Detento detento;
    private List<Vertice> trilhaDaPerseguicao;

    public Minotauro(Labirinto labirinto, Detento detento) {
        super(labirinto, labirinto.getPosicaoMinotauro());
        this.alcance = labirinto.getAlcance();
        this.detento = detento;
        this.emPerseguicao = false;
        this.trilhaDaPerseguicao = new ArrayList<>();
    }

    @Override
    public void mover() {
        if (devePerseguir()) {
            if (!emPerseguicao) {
                emPerseguicao = true;
                trilhaDaPerseguicao.clear();
            }
            movimentoDaPerseguicao();
        } else {
            if (emPerseguicao) {
                emPerseguicao = false;
            }
            movimentosAleatorios();
        }
    }

    boolean devePerseguir() {
        Map<Vertice, Integer> distancias = AlgoritmosEmGrafos.dijkstra(labirinto, atualPosicao);
        int distancia = distancias.getOrDefault(detento.getAtualPosicao(), Integer.MAX_VALUE);
        return distancia <= alcance;
    }

    private void movimentoDaPerseguicao() {
        // Move-se 2 vértices por vez durante perseguição
        for (int i = 0; i < 2; i++) {
            List<Vertice> caminho = AlgoritmosEmGrafos.dijkstraCaminhoMinimo(labirinto, atualPosicao, detento.getAtualPosicao());
            if (caminho.size() > 1) {
                atualPosicao = caminho.get(1); // Próximo vértice no caminho mínimo
                caminhoPercorrido.add(atualPosicao);
                trilhaDaPerseguicao.add(atualPosicao);
            }
            if (atualPosicao.equals(detento.getAtualPosicao())) break;
        }
    }

    private void movimentosAleatorios() {
        List<Aresta> arestasAdjacentes = labirinto.getArestasAdjacentes(atualPosicao);
        if (!arestasAdjacentes.isEmpty()) {
            Aresta arestaEscolhida = arestasAdjacentes.get(new Random().nextInt(arestasAdjacentes.size()));
            atualPosicao = arestaEscolhida.getDestino();
            caminhoPercorrido.add(atualPosicao);
        }
    }

    public boolean encontrouPrisioneiro() {
        return atualPosicao.equals(detento.getAtualPosicao());
    }

    public List<Vertice> getTrilhaDaPerseguicao() {
        return new ArrayList<>(trilhaDaPerseguicao);
    }

    public boolean estaEmPerseguicao() {
        return emPerseguicao;
    }
}